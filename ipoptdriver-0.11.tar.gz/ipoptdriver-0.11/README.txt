The Ipopt Plugin is a driver for the Ipopt 
optimizer ( http://www.coin-or.org/Ipopt/ ) which
is a software package for large-scale nonlinear optimization.

In addition to the requirement of having Ipopt installed, 
the Python wrapper, Pyipopt ( http://code.google.com/p/pyipopt/ ) 
needs to be installed.

To view the Sphinx documentation for this distribution, which includes information on
how to make use of the wrapper, type:

plugin_docs ipoptdriver

